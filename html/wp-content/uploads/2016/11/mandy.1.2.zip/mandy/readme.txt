=== Description ===
In this version you will get the theme Mandy color variant. Couple of templates added which is not found in the parent appointment theme.

=== Support ===
For any ideas, support and feedback you can access the theme forum.


Mandy WordPress Theme, Copyright 2016 Webriti Theme
Mandy is distributed under the terms of the GNU GPL

Screenshot Image
URL: http://pixabay.com/en/office-home-office-creative-apple-581131/
Source:http://pixabay.com
License: CC0 Public Domain

== Version ==
------ 1.0 ------
1. Released.

------ 1.0.1 ------ 
1. Solved Theme Review Issue.

------ 1.1 ------
1. Added Theme URI.
2. Update Theme Tag.

------ 1.2 ------
1. Solved Responsive issue.